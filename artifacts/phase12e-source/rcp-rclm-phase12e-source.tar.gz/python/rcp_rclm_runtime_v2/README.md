# RCP/RCLM Runtime v2

`rcp-rclm-runtime-v2` is the deterministic Python execution layer for the pinned
RCP/RCLM Formal Core v2. It contains Executable Core v2 Phases 1–8 and the first optional
untrusted CPU-only PyTorch learned-successor pilot.

## Implemented layers

```text
Phase 1  immutable records, exact rational/interval mathematics, canonical hashes
Phase 2  generated-source guard and pinned Lean conformance bridge
Phase 3  pure deterministic fail-closed checker
Phase 4  hardened package envelope and 27-case adversarial suite
Phase 5A bounded separate-process reference generator
Phase 6  selector, isolated realizer, rollback, and candidate-package verifier
Phase 7  immutable promotion store, ledger, active pointer, and rollback controller
Phase 8  portable bundle and independent zero-generator replay
PyTorch pilot  isolated one-update proposal, exact evaluation, admission, promotion/rejection, and zero-training replay
```

The mathematical runtime scope is the declared Gate B finite classical reference and the
selected Gate C commuting/diagonal reference. No general noncommuting density-matrix or
CPTP-map implementation is claimed.

## Package map

```text
rcp_rclm_runtime/
  canonical/       canonical JSON, Unicode/path rules, content and tree hashing
  schema/          strict immutable state/update/candidate/certificate records
  mathematics/     exact Gate B and selected Gate C mathematics
  refinement/      executable RCLM-to-RCP mappings
  lean_bridge/     source generation, anti-placeholder gate, compiler, verdict parser
  checker/         Phase 3 checker and Phase 4 hardened request/report
  adversarial/     deterministic attack cases and first-class results
  generator/       Phase 5A protocol, worker, process, and reference loop
  successor/       Phase 6 selection, realization, package, rollback, public verifier
  promotion/       Phase 7 policy, store, ledger, pointer, controller
  replay/          Phase 8 bundle, source guard, records, reproducer
  torch_backend/   optional untrusted PyTorch worker plus model-free host/replay code
```

## Trust boundary

Trusted or trusted after conformance validation:

```text
pinned Lean project and bridge
canonical serializer and hashing
exact/interval mathematical runtime
Phase 3/4 checker
Phase 6 public package verifier
Phase 7 promotion transaction
Phase 8 replay verifier
```

Untrusted:

```text
reference generator
PyTorch model and optimizer
candidate code and files
candidate-provided certificate assertions
candidate-reported scores or acceptance fields
future search, synthesis, LLM, or learned proposal policies
```

PyTorch is prohibited as the source of truth for canonical serialization, hashes,
certificate arithmetic, KL/QRE bounds, trust, checker acceptance, promotion, rollback,
or replay.

## First PyTorch pilot

The optional dependency is declared as:

```bash
python -m pip install '.[torch-pilot]'
```

The pilot uses a frozen `Linear(2, 2)` classifier, CPU-only `float64` training, seed 1729,
one thread, exactly one SGD update, and canonical little-endian `int64` package weights.
The worker receives no held-out labels.

The host path is:

```text
verified predecessor package
→ two isolated proposal processes
→ strict proposal and tensor-manifest validation
→ host-owned Phase 6 selection
→ isolated realization and verified rollback
→ exact framework-independent integer evaluation
→ host-owned Gate B stability certificate
→ generated-Lean source guard and pinned verifier
→ hardened checker
→ atomic Phase 7 promotion or rejection
→ independent replay after removing the training backend
```

The accepted reference changes the model hash, moves held-out correctness from `2/4` to
`4/4`, and preserves the protected class-0 result at `2/2`. The rejection fixture does
not alter the active pointer. Replay records zero training invocations.

## Install and test

```bash
python -m pip install --no-deps -e .
python -m pip install '.[torch-pilot]'
python -m compileall -q rcp_rclm_runtime tests tests_phase2 tests_phase3 tests_phase4 tests_phase5 tests_phase6 tests_phase7 tests_phase8 tests_pytorch_pilot tools
python tools/validate_source_quality.py --package-root . --out source_quality.json
```

Run all suites:

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s tests_phase2 -v
python -m unittest discover -s tests_phase3 -v
python -m unittest discover -s tests_phase4 -v
python -m unittest discover -s tests_phase5 -v
python -m unittest discover -s tests_phase6 -v
python -m unittest discover -s tests_phase7 -v
python -m unittest discover -s tests_phase8 -v
python -m unittest discover -s tests_pytorch_pilot -v
```

Dedicated runners include:

```bash
python tools/run_phase2_conformance.py --repo-root ../.. --outdir ../../artifacts/phase2
python tools/run_phase6_reference_suite.py --outdir ../../artifacts/phase6
python tools/run_phase7_reference_suite.py --outdir ../../artifacts/phase7
python tools/run_phase8_tests.py --package-root . --out ../../artifacts/phase8-tests.log
python tools/run_pytorch_pilot_tests.py --package-root . --out ../../artifacts/pytorch-tests.log
python tools/run_pytorch_pilot_reference.py --outdir ../../artifacts/pytorch-reference
python tools/run_pytorch_pilot_admission_fixture.py --case accepted --outdir ../../artifacts/pytorch-accepted
python tools/run_pytorch_pilot_admission_fixture.py --case rejected --outdir ../../artifacts/pytorch-rejected
```

## Validation records

Phase-specific machine-readable manifests and validation files are stored at the package
root. Human-readable architecture, exit criteria, and exact workflow records are under
`docs/executable_core_v2/`.

## Boundary

This package does not prove arbitrary learned-system refinement, generator completeness,
GPU reproducibility, general noncommuting quantum semantics, external benchmark
performance, or autonomous/unbounded RSI. Its strongest results are finite,
content-addressed, fail-closed, and independently replayable at the declared scopes.
