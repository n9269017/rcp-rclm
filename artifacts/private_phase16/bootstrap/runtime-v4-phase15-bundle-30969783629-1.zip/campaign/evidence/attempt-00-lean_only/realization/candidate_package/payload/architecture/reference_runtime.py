from __future__ import annotations

REFERENCE_RUNTIME_ARCHITECTURE = (
    'generator-proposal',
    'host-selection',
    'isolated-realization',
    'fail-closed-checking',
)
